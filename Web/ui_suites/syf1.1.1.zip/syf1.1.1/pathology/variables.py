# -*- coding: utf-8 -*-
import  os

########################################################################

#原发灶变量
FocusPositionL  = "L";      # 灶位置左
FocusNumL = "";                 
FocusDiamL = "";

FocusPositionR = "";
FocusNumR = "";
FocusDiamR = "";
FocusPositionX = "";
FocusNumX = "";
FocusDiamX = "";
FocusPositionZ= ""
FocusNumZ= "";
FocusDiamZ = "";
FocusOther = "";

#转移灶变量
throat = "";
sternu = "";
Lupper = "";
Lmiddle = "";
Llower = "";
L1b = "";
L2a = "";
L3 = "";
L4 = "";
L5a = "";
L5b = "";
Lmuscle= "";
Lyanp= "";
Lludi= "";
Rupper = "";
Rmiddle = "";
Rlower1_2 = "";
Rlower1_3 = "";
R1b = "";
R2a = "";
R3 = "";
R4 = "";
R5a = "";
R5b = "";
Rmuscle= "";
Ryanp= "";
Rludi= "";


print  FocusPositionL 